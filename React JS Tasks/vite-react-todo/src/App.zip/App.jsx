import { useState } from 'react'
import reactLogo from './assets/react.svg'
import './App.css'
import Todo from './pages/todo/Todo'

function App() {

  return (
    <div className="App">
      <Todo/>
    </div>
  )
}

export default App
