import React from 'react'

export default function Item({id, title, status}) {
    return (
        <li>Hello</li>
    )
}