import React from 'react'
import Input from '../../../components/Input';
import Button from '../../../components/Button';

export default function AddItem({addItem}) {
    const [value, setValue] = React.useState('');

    return (
        <div>
            <Input value={value} onChange={handleChange} />
            <Button onClick={handleClick} />
        </div>
    )
}