import React from 'react'
import TodoList from './todoList/TodoList';
import AddItem from './addItem/AddItem';

export default function Todo() {
    const [tasks, setTasks] = React.useState([]);
    
    return (
        <React.Fragment>
        <AddItem addItem={addItem} />
        <TodoList tasks={tasks} id={id} />
        </React.Fragment>
    )
}